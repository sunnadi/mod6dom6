﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProductAuthApi.Models;


namespace ProductAuthApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : ControllerBase
    {
        private static List<Product> products = new()
        {
            new Product { Id = 1, Name = "Laptop", Price = 350000, Category = "Electronics" },
            new Product { Id = 2, Name = "Mouse", Price = 8000, Category = "Accessories" },
            new Product { Id = 3, Name = "Desk", Price = 45000, Category = "Furniture" }
        };

        [AllowAnonymous]
        [HttpGet]
        public ActionResult<List<Product>> GetAll()
        {
            return Ok(products);
        }

        [AllowAnonymous]
        [HttpGet("{id}")]
        public ActionResult<Product> GetById(int id)
        {
            var product = products.FirstOrDefault(p => p.Id == id);
            if (product == null) return NotFound();
            return Ok(product);
        }

        [Authorize]
        [HttpPost]
        public IActionResult Create(Product newProduct)
        {
            if (newProduct == null || string.IsNullOrWhiteSpace(newProduct.Name))
                return BadRequest();

            var userName = HttpContext.User.Claims
                .FirstOrDefault(c => c.Type == "username")?.Value;

            newProduct.Id = products.Any() ? products.Max(p => p.Id) + 1 : 1;
            products.Add(newProduct);

            return CreatedAtAction(nameof(GetById), new { id = newProduct.Id }, new
            {
                message = $"Товар добавлен пользователем {userName}",
                product = newProduct
            });
        }

        [Authorize]
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var product = products.FirstOrDefault(p => p.Id == id);
            if (product == null) return NotFound();

            products.Remove(product);
            return Ok();
        }
    }
}